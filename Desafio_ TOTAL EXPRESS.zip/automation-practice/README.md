# DESAFIO 1 - TOTAL EXPRESS
A inteligência é o único meio que possuímos para dominar os nossos instintos.

# TESTE

* Compra
  * CT001 - AP - Realizar uma compra com sucesso

# PRÉ-REQUISITOS

Requisitos de software e hardware para executar esse projeto de automação:

* Java 1.8 SDK
* Junit 4.13
* Selenium 3.141.59
* ChromeDriver 81.0.4044.69
* Maven 3.5

# CLONE O PROJETO PARA SUA MÁQUINA LOCAL

Abra o git bash, entre no diretório escolhido na sua máquina e faça o download do projeto com o comando abaixo:

git clone https://gist.github.com/rodrigomarinho05/239d15971ff36b5202c392d8c68d40be

# COMO EXECUTAR OS TESTES

Utilize uma IDE de sua preferencia, recomendado: eclipse ou Intellij;

Abra o projeto na IDE;

Execute o código.

OBS: o Código está em Driver.java

Lembre-se, é necessário que o e-mail seja alterado para que seja feito um novo cadastro!
