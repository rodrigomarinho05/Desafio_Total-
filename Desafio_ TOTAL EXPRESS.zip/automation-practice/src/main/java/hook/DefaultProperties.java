package hook;

public interface DefaultProperties {

    int TIME_OUT = 10;
    String URL_BASE = "http://automationpractice.com/index.php";
}
