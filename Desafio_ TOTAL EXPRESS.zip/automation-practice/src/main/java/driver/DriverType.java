package driver;

public enum DriverType {
    CHROME,
    EDGE
}
